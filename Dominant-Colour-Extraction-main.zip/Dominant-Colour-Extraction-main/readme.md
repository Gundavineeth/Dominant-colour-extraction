This is K Means Clustering Project

Applied K Means Clustering Unsupervised Algorithm in Segmenting an image into set of K Dominant Colours.
Extracted the K Dominant Colours from the image and then re-colorized it using those K Colours.
Tech Stack used are Python, ML(K-Means)
